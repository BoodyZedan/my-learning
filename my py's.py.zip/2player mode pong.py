from peddle import *
from ball import *
from scoreboorde import *
print = Turtle()
hideturtle()


def you_win1():
    print.reset()
    score.reset()
    ball.stop()
    r_peddle.stop()
    l_peddle.stop()
    print.color("white")
    print.up()
    print.hideturtle()
    print.write("player1 won!", align="center", font=("Courier", 80, "normal"))


def you_win2():
    print.reset()
    score.reset()
    ball.stop()
    r_peddle.stop()
    l_peddle.stop()
    print.color("white")
    print.up()
    print.hideturtle()
    print.write("player2 won!", align="center", font=("Courier", 80, "normal"))


alive = True
ball = Ball()
screen = Screen()
screen.bgcolor("black")
screen.title("pong")
screen.setup(width=800, height=600)
width(10)
print.goto(x=0, y=350)

print.rt(90)
for i in range(15):
    print.down()
    print.color("white")
    print.fd(30)
    print.up()
    print.color("black")
    print.fd(30)

r_peddle = Peddle()
l_peddle = Peddle()
score = Score()

r_peddle.goto(x=350, y=0)
l_peddle.goto(x=-350, y=0)
r_peddle.color("white")
l_peddle.color("white")
screen.listen()
screen.onkey(r_peddle.up, "Up")
screen.onkey(r_peddle.down, "Down")
screen.onkey(l_peddle.up, "w")
screen.onkey(l_peddle.down, "s")
game = True
while game:
    
    ball.move()
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce_y()
    if ball.distance(r_peddle) < 20 and ball.xcor() > 320 or ball.distance(l_peddle) < 20 and ball.xcor() < -320:
        ball.bounce_x()
    if ball.xcor() > r_peddle.xcor():
        ball.ball_deidact2()
        score.l_score_plus()
    if ball.xcor() < l_peddle.xcor():
        ball.ball_deidact1()
        score.r_score_plus()
    if score.l_score == 5:
        you_win1()
        game = False
    if score.r_score == 5:
        you_win2()
        game = False
screen.exitonclick()
